<!DOCTYPE html>
<html>
<head>
<style>
.button
{

border:none;
text-align:center;
text-decoration:none;
display:inline-block;
font-size:16px;
margin:4px 2px;
cursor:pointer;
color:white;background-color:red;padding: 11px 32px;border-radius:12px;
}
</style>
<meta charset="ISO-8859-1">
<title>Question Bank</title>
</head>
<body oncontextmenu="return false;">
<header style="background-color: powderblue;border-radius: 15px;">
<center><br><br>
<h1><b><i style="color: white;font-size:2vw;">Online Examination Management System</i></b></h1></center><br>
</header>
<form action="studentQuestion.php" method="post">
<center>
<br><hr><h3 style="color:white;background-color: purple">My Question Bank</h3><hr><br>


<input type="button" class="button" value="Exit" onclick="location.href='studentpanel.php'" >
</center>
</form><br>
<footer style="background-color: powderblue;" >
<MARQUEE style="color: black; background-color: red;">NOTICES:</MARQUEE><br>
<br><center><h4 style="color: white;font-size:2vw;">@All rights Reserved &nbsp;&nbsp;&nbsp;Powered by GitamStudents</h4></center>
</footer>
</body>
</html>