# LetsH
This is a Exam Managment Website created for my final year project.I created this project with my group for our college website.It contains Exam section for Students and can be 
managed by Admins of different departments.It is easy to navigate and flexible.We completed this project in March 2020.It has support to conduct various types of exams like AI proctored exam,MCQ tye exams etc.It is created for college and university purposes only.It can be upgradable to new version.
Technologies used:
We used HTML5,CSS3,Javascript,PHP,MySql,Bootstrap to create this project.
Minimum Requirements:
Windows
It can be launched by XAMP and Wamp too.
It smoothly works in chrome and mozilla firefox.
First page is Page1.php

