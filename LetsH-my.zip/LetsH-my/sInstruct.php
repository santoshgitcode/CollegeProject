<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	
	
	<style type="text/css" media="screen">
			body { margin: 0;
    padding: 0;
    height: 100%;
font-size: 100%;
  font-family: "Lato", sans-serif;
background-image:url("images/bg.jpg");
background-size: cover;
}

 body::after
 {
height: 200px;
 }
.logo img{
   float: left;
   width: 150px;
   height: auto;
   margin: 20px;
}
.button
{
position:inherit;
border:none;

text-align:center;
text-decoration:none;
display:inline-block;
font-size:18px;
cursor:pointer;
background-position:10px 10px;
background-repeat:no-repeat;
padding:12px 20px 12px 40px;

}
.button:hover{
  background-color: #444;
}
.button1
{border-radius:8px;
background-color:red;padding: 14px 32px;
opacity: 0.9;
color:white;}

.h{
  background-image: url("images/header.jpg");position:inherit;height: 230px;width:100%;background-size: cover;opacity:0.9;
}

.f{
background-image: url("images/bg02.jpg");position:absolute;width:100%;height:200px;opacity:0.9;
}
</style>
<SCRIPT type="text/javascript">
    window.history.forward();
    function noBack() { window.history.forward(); }
</SCRIPT>
<meta charset="utf-8">
<title>ONLINE EXAMINATION</title>

		
	
</head>
<body oncontextmenu="return false;">
	<header class="h"  style="border-radius:15px;">
		<br><br>
			<div class="logo">
        <img src="images/do.jpg">
      </div>
	<center>
<h1><b><i style="color:white;cursor:default;font-size:2vw;">Exam Section</i></b></h1></center>
</header>
<center>
<br><br><h3 style="background-color: #111;color: white;font-size:1vw;opacity: 0.7">Instruction  panel</h3><br><hr><br><br><br><br><br><br><div class="row"></div>	

<table  width="100%" height="60%" cellpadding="5" cellspacing="5" style="background-color: grey;opacity:0.8; ">
<tr><th style="color:purple;">For Student:</th></tr>
<tr><td style="color:white;">1.<p></p></td></tr>
<tr><td style="color:white;">2.<p></p></td></tr>
<tr><td style="color:white;">3.<p></p></td></tr>
<tr><td style="color:white;">5.<p></p></td></tr>
<tr><td style="color:white;">6.<p></p></td></tr>


    </table><br>


<br><hr>
<button class="button button1" onclick="location.href='Page1.php'">Exit</button>

</center>
<br><br>
<footer class="f"  style="border-radius:30px;" >
<MARQUEE style="color: white; background-color: red;font-size:1vw;opacity: 0.9;"><b>NOTICES:</b></MARQUEE><br>
<br><center><h4 style="color: white;font-size:1vw;">@All rights Reserved &nbsp;&nbsp;&nbsp;Powered byGitamStudents</h4></center><center>  <button type="button" class="btn-social btn-facebook-filled btn-circle" onclick="location.href='https://www.facebook.com/login'"><b class="fa">f</b></button>
  <button type="button" class="btn-social btn-twitter-filled btn-circle" onclick="location.href='https://www.twitter.com/login'"><b class="fa">t</b></button>
  <button type="button" class="btn-social btn-google-filled btn-circle" onclick="location.href='https://www.google.com/gmail'"><b class="fa">@</b></button>
</center>
<br><br><br><br>
</footer>
</div>
  
</body>
</html>